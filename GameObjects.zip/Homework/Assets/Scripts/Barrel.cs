﻿using UnityEngine;
using System.Collections;

public class Barrel : MonoBehaviour {

	GameObject barrel;
	public GameObject target;

	
	Vector3 distance;
	// Use this for initialization
	void Start () {
		barrel = GameObject.Find ("Barrel");
		
	}
	
	// Update is called once per frame
	void Update () {
		

		barrel.transform.LookAt (target.transform.position);

		barrel.transform.localRotation = Quaternion.Euler (new Vector3 (transform.eulerAngles.x+90f, 0, 0));
		
	}
}
