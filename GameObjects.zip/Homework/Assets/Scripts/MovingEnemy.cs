﻿using UnityEngine;
using System.Collections;

public class MovingEnemy : MonoBehaviour {
	
	public GameObject target;
	public float movingSpeed;
	float turningSpeed;
	
	Transform movingEnemy;
	GameObject rocket;
	float delayFire = 0.1f;
	float firingRange;
	
	int maxRange=15;
	void Awake()
	{
		turningSpeed = 7f;
		//parent of the scriptOwner
		movingEnemy = transform.parent;
		
		rocket =(GameObject) Resources.Load ("Prefabs/Rocket");
	}
	
	// Update is called once per frame
	void Update () {
		//LookAt with delay of 1 second
		Quaternion rotation = Quaternion.LookRotation(target.transform.position - transform.position);
		transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * turningSpeed);
		//Delaytime
		delayFire -= 0.5f * Time.deltaTime;
		
		//Locks the base of the movingEnemy
		movingEnemy.eulerAngles = new Vector3(0, transform.eulerAngles.y, 0);
		movingEnemy.LookAt (target.transform.position);
		movingEnemy.position += movingEnemy.forward * movingSpeed * Time.deltaTime;
		transform.LookAt (target.transform.position);
		
		transform.localRotation = Quaternion.Euler (new Vector3 (transform.eulerAngles.x+90f, 0, 0));
		
		firingRange = Vector3.Distance (transform.position, target.transform.position);
		
		if (Mathf.Abs(firingRange)<=maxRange && delayFire <= 0) {
			
			Instantiate(rocket);
			
			rocket.transform.position = transform.position;
			
			rocket.transform.LookAt(target.transform.position);
			
			delayFire =0.1f; 
		}
	}
	//Flamethrower
	//	IEnumerator  Shoot()
	//	{
	//		Instantiate(rocket);
	//		rocket.transform.position = barrel.transform.position;
	//		rocket.transform.LookAt(target.transform.position);
	//		yield return new WaitFordelayFire(10);
	//	}
}
