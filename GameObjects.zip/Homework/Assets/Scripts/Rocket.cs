﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Rocket : MonoBehaviour {

	public int speed=20;
	public float timeTillDestroy=0.25f;
	// Use this for initialization
	void Start () {
		 
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		transform.position += this.transform.forward * speed * Time.deltaTime;
		timeTillDestroy -= Time.deltaTime;
		if (timeTillDestroy <= 0) 
		{
			Destroy (this.gameObject);
		}
	}
}
