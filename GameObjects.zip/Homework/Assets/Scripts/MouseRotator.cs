﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MouseRotator : MonoBehaviour {
	public Slider horizontalSpeedSlider;
	public Slider verticalSpeedSlider;
	public GameObject target;
	float mouseX;
	float mouseY;

	void FixedUpdate () {

		float mouseX = Input.GetAxisRaw ("Mouse X")*horizontalSpeedSlider.value*Time.deltaTime;
		float mouseY = -Input.GetAxisRaw ("Mouse Y")*verticalSpeedSlider.value*Time.deltaTime;
		//Look Up and Down
		transform.Rotate (mouseY, 0f, 0f);
		//Look Around
		target.rigidbody.transform.Rotate (0f, mouseX, 0f);
		//prevents rotations from rigitBody (spinning all the time)
		target.rigidbody.freezeRotation = true;
//		target.rigidbody.velocity = Vector3.zero;



	}
}
