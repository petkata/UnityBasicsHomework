﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MovePlayer : MonoBehaviour {
	public Slider healthBar;
	public int speed = 5;
	public GameObject textGameOver;
	Animator anim;
	float currHealth;
	float maxHealth;
	float minHealth;

	void Awake()
	{
//		anim = GetComponent <Animator> ();
		healthBar.maxValue = 50;
		maxHealth = healthBar.maxValue;
		healthBar.minValue = 0;
		minHealth = healthBar.minValue;
		//healthBar.value = 100;
		currHealth = maxHealth;
	}

	void Update()
	{
		if (currHealth <= minHealth) {
//			anim.SetTrigger("Die");
			DestroyObject(GameObject.Find("Rocket(Clone)"));
			currHealth = minHealth;
			Time.timeScale = 0;
			textGameOver.SetActive (true);
		}
	}
	void FixedUpdate() 
	{
		healthBar.value = currHealth;
		//walk
		float h = Input.GetAxisRaw ("Horizontal");
		float v = Input.GetAxisRaw ("Vertical");

		Vector3 movement = new Vector3 (h, 0f, v);
		movement.Normalize ();

		transform.Translate (movement*speed*Time.deltaTime);

//		Animating (h, v);

		//Run
//		if (Input.GetKeyDown (KeyCode.LeftShift)) {
//			speed += 15;
//		}
//		if (Input.GetKeyUp (KeyCode.LeftShift)) {
//			speed -= 15;
//		}
	}

	void OnTriggerEnter(Collider other) {
	
		Destroy (other.gameObject);
		currHealth--;
		
	}

//	void Animating (float h, float v)
//	{
//		// Create a boolean that is true if either of the input axes is non-zero.
//		bool walking = h != 0f || v != 0f;
//		
//		// Tell the animator whether or not the player is walking.
//		anim.SetBool ("isMoving", walking);
//	}
}
