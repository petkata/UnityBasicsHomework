﻿using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {

	float time = 0.0f;
	
	void Update()
	{
		time += Time.deltaTime;
		guiText.text = "Score: " + time.ToString ("F3");
	}
}
