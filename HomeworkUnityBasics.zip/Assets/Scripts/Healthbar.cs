﻿using UnityEngine;
using System.Collections;
//unity4.5 HealthBar
public class Healthbar : MonoBehaviour {
	private int health=50;
	private int curHealth=50;
	public GameObject textGameOver;
	public GameObject textRestart;
	public GameObject textQuit;

	void OnGUI() 
	{
		//HealthBar
		Texture2D texture = new Texture2D(100, 20);
		GUI.BeginGroup(new Rect (10, 10, 200, 20));
		GUI.color = Color.gray;
		GUI.DrawTexture (new Rect(0, 0,health, 20),new Texture2D(100,20));
		GUI.color = Color.red;
		GUI.DrawTexture (new Rect(0, 0,curHealth, 20),texture);
		GUI.color = Color.white;
		GUI.Label (new Rect (0, 0, 50, 20),curHealth+"|"+health);
		GUI.EndGroup ();
		//GUI.Box (new Rect (10, 10, 100, 20),"")
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (curHealth<=0) {
			curHealth = 0;
			Time.timeScale=0;
			textGameOver.SetActive(true);
			textRestart.SetActive(true);


				}
	}
	void OnTriggerEnter(Collider other) {
		other.transform.position = new Vector3(other.transform.localPosition.x+0.5f, 1,
		                                       other.transform.localPosition.z+0.5f);
		curHealth--;

	}

	void OnTriggerStay(Collider other) {
		other.transform.position = new Vector3 (other.transform.localPosition.x + 0.5f, 1,
		                                        other.transform.localPosition.z + 0.5f);
		}


}
