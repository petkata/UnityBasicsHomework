﻿using UnityEngine;
using System.Collections;
//unity4.5
public class Enemy1Script : MonoBehaviour {
	private Transform target;
	private Transform myTransform;
	//private int rotationSpeed=5;
	private int movingSpeed=9;
	void Awake(){
		myTransform = transform;
		}
	// Use this for initialization
	void Start () {
		GameObject player = GameObject.FindGameObjectWithTag("Player");
		target = player.transform;
	}

	// Update is called once per frame
	void Update () {
		//myTransform.rotation=Quaternion.Slerp(
		//	myTransform.rotation ,
		//	Quaternion.LookRotation(target.position-myTransform.position),rotationSpeed*Time.deltaTime);
		myTransform.transform.LookAt (target.position);
		myTransform.position += myTransform.forward * movingSpeed * Time.deltaTime;
	}
}
