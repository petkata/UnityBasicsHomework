﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public Camera cam;

	private Vector3 movement;
	private Vector3 dir;

	void Awake(){
		Time.timeScale = 1;
		}
	void Update(){
		gameObject.rigidbody.WakeUp ();
		}
	void FixedUpdate () {

		dir = Vector3.zero;		//android

			//android
			dir.x = Input.acceleration.y;
		dir.y = 1;
			dir.z = -Input.acceleration.x;
			


		if (dir.sqrMagnitude > 1)
			dir.Normalize();
		rigidbody.AddForce (dir*1000*Time.deltaTime);

		if (Input.GetKey(KeyCode.UpArrow)||Input.GetKey(KeyCode.W)) {
			transform.Translate (0f, 0f, -11f*Time.deltaTime);

		}
		if (Input.GetKey(KeyCode.DownArrow)||Input.GetKey(KeyCode.S)) {
			transform.Translate (0f, 0f, 11f*Time.deltaTime);

		}
		if (Input.GetKey(KeyCode.LeftArrow)||Input.GetKey(KeyCode.A)) {

			//transform.Translate (-5f*Time.deltaTime, 0f, 0f);
			transform.Rotate(0f,-100f*Time.deltaTime,0f);
		}
		if (Input.GetKey(KeyCode.RightArrow)||Input.GetKey(KeyCode.D)) {
			//transform.Translate ( 5f*Time.deltaTime, 0f, 0f);
			transform.Rotate(0f,100f*Time.deltaTime,0f);
		}
		cam.transform.LookAt (GameObject.FindGameObjectWithTag("Player").transform);
	}


}
