﻿using UnityEngine;
using System.Collections;

public class Menus : MonoBehaviour {

	public bool isQuit;
	public bool isRestartLevel;

	void OnMouseEnter()
	{

		renderer.material.color = Color.red;
		
	}
	void OnMouseExit()
	{
		renderer.material.color = Color.white;
	}
	void OnMouseUp()
	{
		if (isQuit) {
			Application.Quit ();
		} 
		else if (isRestartLevel) {
			Application.LoadLevel(Application.loadedLevel);

		} 


	}
}
