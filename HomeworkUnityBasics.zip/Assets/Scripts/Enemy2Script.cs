﻿using UnityEngine;
using System.Collections;

public class Enemy2Script : MonoBehaviour {
	private Transform target;
	private Transform myTransform;
	private int rotationSpeed=3;
	private int movingSpeed=9;
	void Awake(){
		myTransform = transform;
		}
	// Use this for initialization
	void Start () {
		GameObject player = GameObject.FindGameObjectWithTag("Enemy1");
		target = player.transform;
	}

	// Update is called once per frame
	void Update () {
		//Using the rotationSpeed
		myTransform.rotation=Quaternion.Slerp(
			myTransform.rotation ,
			Quaternion.LookRotation(target.position-myTransform.position),rotationSpeed*Time.deltaTime);
		myTransform.position += myTransform.forward * movingSpeed * Time.deltaTime;
	}
}
